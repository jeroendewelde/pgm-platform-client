import Card from "./Card";
import HeroCourse from "./HeroCourse";
import DocentenCourse from "./DocentenCourse";
import CourseProjects from "./CourseProjects";

export { Card, HeroCourse, DocentenCourse, CourseProjects };
